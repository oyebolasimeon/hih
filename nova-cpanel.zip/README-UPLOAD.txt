Nova Elite Homes — cPanel upload pack
=====================================

1) In cPanel open "Setup Node.js App"
2) Create/edit application:
   - Node.js version: 20.x or newer
   - Application mode: Production
   - Application root: nova (or your chosen folder)
   - Application URL: your domain (e.g. novaelitehomes.co.uk)
   - Application startup file: server.js
3) Upload/extract this package into the Application root
   (enable Show Hidden Files so .next is included)
4) Click "Run NPM Install" if node_modules/next is missing
5) Environment Variables:
   - TURNSTILE_SECRET_KEY=your_turnstile_secret
6) Restart the app
7) In Cloudflare Turnstile, add your live domain to Allowed Hostnames
8) Test the contact form

If the old website still shows, rename public_html/index.html to index.html.bak
