globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/E4On1_4A9wROIbyLAEhdd/_buildManifest.js",
    "static/E4On1_4A9wROIbyLAEhdd/_ssgManifest.js",
    "static/E4On1_4A9wROIbyLAEhdd/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/08ttfj81-47mu.js",
    "static/chunks/0td_q_jvg2olo.js",
    "static/chunks/turbopack-1ht71va82inkw.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
